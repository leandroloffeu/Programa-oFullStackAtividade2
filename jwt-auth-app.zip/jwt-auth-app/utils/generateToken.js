const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/config');

const generateToken = (userId) => {
  return jwt.sign({ id: userId }, jwtSecret, { expiresIn: '1h' });
};

module.exports = generateToken;
