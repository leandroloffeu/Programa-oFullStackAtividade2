// config/config.js
module.exports = {
    jwtSecret: process.env.JWT_SECRET || 'sua_jwt_secret_key',
  };
  
