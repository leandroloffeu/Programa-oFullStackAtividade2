const express = require('express');
const mongoose = require('mongoose');
const authRoutes = require('./routes/authRoutes');
require('dotenv').config();
const { connectDB } = require('./config/db');

const app = express();
const port = process.env.PORT || 5000;


connectDB();


app.use(express.json());


app.use('/api/auth', authRoutes);

app.listen(port, () => {
  console.log(`Servidor Rodando na porta: ${port}`);
});
