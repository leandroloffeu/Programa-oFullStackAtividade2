const express = require('express');
const { register, login } = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

// Register
router.post('/registrar', register);

// Login
router.post('/login', login);

// Protected route
router.get('/protected', authMiddleware, (req, res) => {
  res.json({ message: 'Esta é uma rota protegida', user: req.user });
});

module.exports = router;
